<?php
session_start();

//This page contains a User creation form with the common required fields
//It uses jQuery Validate to check the form entries without having to POST the data and refresh the page
//There is some PHP below on line 209 for the State Container - The list of states are pulled from a Database

?>
	<!doctype html>

	<head>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>

		<script type='text/javascript'>
			//Validate the form
			$(function() {
				// Setup form validation on the #register-form element
				$("#signUpForm").validate({

					// Specify the validation rules
					rules: {
						email:			{required: true, email:true},
						verifyEmail:	{required: true, email:	true},
						password: 		"required",
						verifyPassword: "required",
						billCompany: 	"required",
						billFirstName: 	"required",
						billLastName: 	"required",
						billAddress1: 	"required",
						billAddress2: 	"required",
						billCity: 		"required",
						billCountry: 	"required",
						billState: 		"required",
						billPostalCode: "required",
						billPhone: 		'customphone', "required",
						billCellPhone: 	'customphone', "required"
					},

					// Specify the validation error messages
					messages: {
						email: "You must enter a valid email address."
					},

					submitHandler: function(form) {
						form.submit();
					}
				});

				//Custom phone validation method using a RegEx to actually check for valid phone number
				$.validator.addMethod('customphone', function (value, element) {
					return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value);
				}, "Please enter a valid phone number");

			});
		</script>

	</head>	

	<body>
		<!-- Header div Starts here -->
		<header id="header">
			<div class="menuContainer">
				<div id="logo">
					<a href="index.html"> <img src="images/logo.png" alt="" title=""> </a>
				</div>
				<div id="menu-container">
					<nav id="main-menu">
						<ul class="group">
							<li class="menu-item current_page_item"><a href="index.php#home">Home</a></li>
							<li class="menu-item"><a href="index.php#services">Services</a></li>
							<li class="menu-item"><a href="index.php#pricing">Pricing</a></li>
							<li class="menu-item"><a href="index.php#company">Company</a></li>
							<li class="menu-item"><a href="index.php#contact">Contact Us</a></li>
						</ul>
					</nav>
				</div>                    
			</div>


			<?php if (isset($_SESSION['username'])) {
				//If the user is logged in, display their name and Account Page button + Logout / else show them a Login button
			?>

			<div class="logoutContainer">
				<p style="color:white; font-size: 11px;">Welcome <?php echo $_SESSION['fname'] . " " . $_SESSION['lname'] . ","; ?><br />
				Access your <a href="members.php" style="color: #FFF500;">Account Page</a></p>
				<div id="accountLogout" class="logout">
					<a href="logout.php">Logout</a>
				</div>
			</div>			
			<?php
			} else { ?>

			<div id="accountLogin">
				<a href="login.php">Login Here</a>
			</div>

			<?php } ?>

		</header>
		<!-- Header div Ends here -->
		<div id="main">
		
		<section id="home" class="content">
			<div class="shadow"></div>
		</section>



		<section id="services" class="content">
			<div class="main-title">
				<div class="container">
					<h2>Business Leads</h2>
				</div>
			</div>
			<div class="content-main">

			<div class="container">

			<h1 class="first">Create Account</h1>

			<div class="createAccountForm">
			<form action="updateAccount.php" method="post" id="signUpForm">

				<div class="form_column1">	
					<div id="loginInfo">
						<h3>Login Info</h3>
							<dt>
								<span class="FormFieldLabel"><strong>Email Address (Username)</strong>:</span>
							</dt>
							<dd>
							<input type="text" class="createAccountInput" id="email" name="email"  value="" />
							</dd>

							<dt>
							<span class="FormFieldLabel"><strong>Confirm Email Address</strong>:</span>
							</dt>
							<dd>
							<input type="text" class="createAccountInput" id="verifyEmail" name="verifyEmail"  value="" />
							</dd>

							<dt>
							<span class="FormFieldLabel">Password:</span>
							</dt>
							<dd>
							<input type="password" class="createAccountInput" id="password" name="password"  value="" />
							</dd>

							<dt>
							<span class="FormFieldLabel">Retype Password:</span>
							</dt>
							<dd>
							<input type="password" class="createAccountInput" id="verifyPassword" name="verifyPassword"  value="" />
							</dd>
					</div>
				</div>
				<div class="form_column2">
					<h3>Billing Info</h3>
					<dt>
						<span class="FormFieldLabel">Company:</span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput" id="billCompany" name="billCompany"  value="" />
					</dd>
					<dt>
						<span class="FormFieldLabel">First Name:</span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput" id="billFirstName" name="billFirstName"  value="" />
					</dd>
					<dt>
						<span class="FormFieldLabel">Last Name:</span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput" id="billLastName" name="billLastName"  value="" />
					</dd>
					<dt>
						<span class="FormFieldLabel">Address Line 1:</span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput" id="billAddress1" name="billAddress1"  value="" />
					</dd>
					<dt>
						<span class="FormFieldLabel">Address Line 2:</span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput" id="billAddress2" name="billAddress2"  value="" />
					</dd>
					<dt>
						<span class="FormFieldLabel">City:</span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput" id="billCity" name="billCity"  value="" />
					</dd>
					<dt>
						<span class="FormFieldLabel">Country:</span>
					</dt>
					<dd>
						<select class="createAccountInputFormField" id="billCountry" name="billCountry"  size="1" value="">
						<option value="US">United States</option>
					</select>
					</dd>

					<dt>
						<span class="FormFieldLabel">State:</span>
					</dt>

					<dd>
						<div id="statecontainer">
					
						<?php // Some database connection code here (MSSQL Server in this case, but have worked with MySQL and SQLite as well)

							$serverName = "111.222.333.45, 50504";
							$connectionInfo = array("Database"=>"CITMain1", "UID"=>"citMain", "PWD"=>"datadata");
							$conn = sqlsrv_connect($serverName, $connectionInfo) or die("failed to connect");

							//Get The States and Put them in an array
							$query = "SELECT * From statelist ORDER BY stname";
							$result = sqlsrv_query($conn, $query);
							$count = 0;
							echo "<select name=\"billState\" id=\"billState\" class=\"FormField createAccountInput\" >";
							echo "<option value=\"\"></option>";
							while ($row = sqlsrv_fetch_array($result)) {
								echo "<option value=\"" . $row['stAbb'] . "\">" . $row['stname'] ."</option>";	
							}
							echo "</select>";
							sqlsrv_close($conn);
							
						?>

						</div>
					</dd>


					<dt>
						<span class="FormFieldLabel">Zip/Postcode:</span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput" style="width:60px;" id="billPostalCode" name="billPostalCode"  value="" />
					</dd>

					<dt>
						<span class="FormFieldLabel"><strong>Phone:</strong></span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput phone-group" id="billPhone" name="billPhone"  value="" />
					</dd>		

					<dt>
						<span class="FormFieldLabel"><strong>Cell Phone:</strong></span>
					</dt>
					<dd>
						<input type="text" class="createAccountInput phone-group" id="billCellPhone" name="billCellPhone"  value="" />
					</dd>

				</div>
				<input type="submit" class="createAccountButton" value="Create Account" />
			</form>
			<button class="cancelAccountButton"><a href="index.php">Cancel Sign Up</a></button>

		</section>


	</body>
</html>

<?php
// Close any open DB connection.
sqlsrv_close( $conn ); ?>  