<?php
	//This page uses a CURL HTTP request to retrieve the User's country based on their IP address to display US/Canadian localized pages
	//handler.php includes this script and uses the returned country to display different images/text/phone numbers
	session_start(); 

	global $timeout;
	$timeout = 0;
	  
	$userIP = $_SERVER['REMOTE_ADDR'];

	//License Key, along with the User's IP address was passed in the URL below
	$url = 'http://geoip.maxmind.com/a?l=LicenseKeyGoesHere=' . $userIP;

	//Run the script and get the return value which is the user's Country
	$result = get_country($url);
		
		if ($timeout == 0) {
		
			//Set the country as a session variable so handler.php can access the info
			$_SESSION['country'] = $result;
			//Debugging: echo "The result is: " . $_SESSION['country'];
		
		}
		//Debugging: If there are issues getting the Country some fallback code could go here as an ELSE. 
		//The client had requested a default fallback to Canada however so this was not needed
	
	
	function get_country($path){
			// Initiate the CURL HTTP Request passing the URL with License and User IP and return the originating Country
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$path);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
			curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
			curl_setopt($ch, CURLOPT_TIMEOUT_MS, 4000);
			$curl_errno = curl_errno($ch);
			$curl_error = curl_error($ch);
			$retValue = curl_exec($ch);
			curl_close($ch);
			

		/*	if ($curl_errno > 0) {
				
				//Debugging: If issues with the CURL request occur, a fallback could go here as well but again this was not needed by the client
			} 
		*/
		
		return $retValue;
		
	}
  
?>
