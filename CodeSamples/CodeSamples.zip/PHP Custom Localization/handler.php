<?php
	//This code is used to serve up different page content based on the User's country of origin
	//The product page for instance, FireQRVS.com had the respective US/Canadian parent company text, links, images
	//All pages include this handler and the variables below are Echo'd in place of hard-coded content for text, links, images, etc. 
	
	session_start(); 

	//If the country is not already set as a session variable, run the getCountry script to set this first
	if (!isset($_SESSION['country'])) {
		include 'getCountry.php';
	}
		
//United States handling - US has different company name (Thuh Company), info, images. Sells same products but has US and CA versions
	if  ($_SESSION['country'] == "US") {

		//US Company Text/Images/Div Classes
		$CompanyName = "Thuh Company";
		$BannerImage = "slider-thuhcompany.jpg";
		$companyLogoImg = "http://www.thuhcompany.com/images/logo-thuhcompany.png";
		$logoClass = "thuhCompanyLogo";
		$panelImg = "panel-thuhcompany.png";
		$homeURL = "www.thuhcompany.com";
		$companyAddress = "440 Quadrangle Drive, Suite D<br>Bolingbrook, IL 60440";
		$shortURL = "thuhcompany.com";
		$companyPhone = "1-888-618-5030";
		$faxPhone = "1-815-722-8802";
		$tollfreePhone = "1-888-618-5030";
		
		//Paths 
		$homePath = "http://www.thuhcompany.com";
		$companyPath = "http://www.thuhcompany.com/company";
		$productsPath = "http://www.thuhcompany.com/products";
		$mySOSPath = "http://www.thuhcompany.com/mysos/";
		$ggmPath = "http://www.thuhcompany.com/ggm/Home.php";
		$contactPath = "http://www.thuhcompany.com/contact";
		$privacyPath = "http://www.thuhcompany.com/privacy";
		$sitemapPath = "http://www.thuhcompany.com/sitemap";
		$fireQRVSPath = "http://www.thuhcompany.com/fireqrvs/responseVerification";
		$logoPath = "http://www.thuhcompany.com";
		$fireQLogoClass = "fireqLogo";
		$GGMLogoClass = "GGMLogo";
		
		//Product 1 Download Page Links
		$downloadCountry = "US";
		$downloadLink64 = "http://74.208.144.204/FTP/FireQfiles/FireQSetup-US-64Bit.zip";//"http://74.208.144.204/FTP/FireQfiles/FireQRVS-64.exe";
		$downloadLink32 = "http://74.208.144.204/FTP/FireQfiles/FireQSetup-US-32Bit.zip";//"http://74.208.144.204/FTP/FireQfiles/FireQRVS-32.exe";
		$downloadLinkPatch = "http://74.208.144.204/FTP/FireQfiles/FireQRVS-patch.exe";
		$updateLink = "http://74.208.144.204/ftp/FireQfiles/FireQRVS-patch.exe";
		$downloadFlagImg = "http://www.thuhcompany.com/images/downloadUS.png";
		$downloadText = "<span><strong>US Version</strong> - For the Canadian version <a href=\"buy?download=CA\" style=\"color: #a40303; font-weight: bold;\" >CLICK HERE</a></span>";
		$brouchureLink = "http://www.fireqrvs.com/fireqrvs/forms/FireQ-Brouchure1-US.pdf";
		
		//Product 2 Download Page
		$GGMLink32 = "http://74.208.144.204/FTP/GoGreen/GGMClient32.exe";
		$GGMLink64 = "http://74.208.144.204/FTP/GoGreen/GGMClient64.exe";
		$GGMText = "<p><strong>US Version</strong> - For the Canadian version <a href=\"Downloads.php?download=CA\" class=\"GGMTextDownload\">CLICK HERE</a></p>";
		
		//Info Form (needed due to custom text request on Canadian page)
		$infoFormText = "";
		
		//Analytics Path (used as include on page)
		$analyticsPath = "analytics/analyticsUS_fireq.php";
	
	} else {
	
//Handler For Canada or any other countries -- Defaults to Breton SmarTek (Canadian) info as per request

	//Canadian Company Text/Images/Div Classes
	$CompanyName = "Breton SmarTek";
	$BannerImage = "slider-bretonsmartek.jpg";
	$companyLogoImg = "http://www.bretonsmartek.com/images/logo-bretonsmartek.png";
	$logoClass = "bretonSmartekLogo";
	$fireQLogoClass = "fireqLogo";
	$GGMLogoClass = "GGMLogo";
	$panelImg = "panel-bretonsmartek.png";
	$homeURL = "www.bretonsmartek.com";
	$shortURL = "bretonsmartek.com";
	$companyAddress = "PO Box 266 Stn A <br /> Sydney, NS, B1P-6H1";
	$companyPhone = "(902)-442-7588 / 1-888-600-7122";
	$faxPhone = "(902)-702-2533";
	$tollfreePhone = "1-888-600-7122";
	
	
	//Paths
	$homePath = "http://www.bretonsmartek.com";
	$companyPath = "http://www.bretonsmartek.com/company";
	$productsPath = "http://www.bretonsmartek.com/products";
	$mySOSPath = "http://www.bretonsmartek.com/mysos/";
	$ggmPath = "http://www.bretonsmartek.com/ggm/Home.php";
	$contactPath = "http://www.bretonsmartek.com/contact";
	$privacyPath = "http://www.bretonsmartek.com/privacy";
	$sitemapPath = "http://www.bretonsmartek.com/sitemap";
	$fireQRVSPath = "http://www.bretonsmartek.com/fireqrvs/responseVerification";
	$logoPath = "http://www.bretonsmartek.com";
	$fireQLogoClass = "fireqLogo";
	$GGMLogoClass = "GGMLogo";
	
	//Product 1 Download Page
	$downloadCountry = "CA";
	$downloadLink64 = "http://74.208.144.204/FTP/FireQfiles/FireQSetup-CA-64Bit.zip";//"http://74.208.144.204/FTP/FireQfiles/FireQRVS-64CA.exe";
	$downloadLink32 = "http://74.208.144.204/FTP/FireQfiles/FireQSetup-CA-32Bit.zip";//"http://74.208.144.204/FTP/FireQfiles/FireQRVS-32CA.exe";
	$downloadLinkPatch = "http://74.208.144.204/FTP/FireQfiles/FireQRVS-patch-CA.exe";
	$updateLink = "http://74.208.144.204/ftp/FireQfiles/FireQRVS-patch-CA.exe";
	$downloadFlagImg = "http://www.bretonsmartek.com/images/downloadCA.png";
	$downloadText = "<span><strong>Canadian Version</strong> - For the US version <a href=\"buy?download=US\" style=\"color: #a40303; font-weight: bold;\" >CLICK HERE</a></span>";
	$brouchureLink = "http://www.fireqrvs.com/fireqrvs/forms/FireQ-Brouchure1-CA.pdf";
	
	//Product 2 Download Page
	$GGMLink32 = "http://74.208.144.204/FTP/GoGreen/GGMClient32-CA.exe";
	$GGMLink64 = "http://74.208.144.204/FTP/GoGreen/GGMClient64-CA.exe";
	$GGMText = "<p><strong>Canadian Version</strong> - For the US version <a href=\"Downloads.php?download=US\" class=\"GGMTextDownload\" >CLICK HERE</a></p>";
		
	//Info Form (some custom text was requested for the Canadian page)
	$infoFormText = "<p>Once we have received your request, we will contact you to set up your account and gather some additional information. Please feel free to fill out this <a href=\"forms/FireQRVS_SetupForm.pdf\" style=\"color: #a40303; font-weight: bold;\" >Required Information Form</a> in advance and email it to <a href=\"mailto:info@bretonsmartek.com?Subject=FireQ-RVS%20Information%20Form:\">info@bretonsmartek.com</a>.</p>";
	
	//Analytics Path (used as include on page)
	$analyticsPath = "analytics/analyticsCA_fireq.php";
	}
?>